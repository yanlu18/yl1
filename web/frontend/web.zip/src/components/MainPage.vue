<template>
    <div class="first">
        欢迎来到自动门禁系统网页平台
    </div>
</template>

<style scoped>
    .first{
        color: rgb(0, 0, 0);
        font-size: xx-large;
    }
</style>
