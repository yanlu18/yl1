import getWrapper from "./utils"

import App from '@/App.vue'


describe('App.vue', () => {

  //const wrapper = getWrapper(App,{})
  it('simple coverage', () => {
  //  console.log(wrapper.findAll("MessageBlock").length)
  })
})
