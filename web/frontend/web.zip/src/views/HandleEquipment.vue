<template>
  <div id="handleequipment">
    <Equipment/>
  </div>
</template>

<script>
  import Equipment from "@/components/Equipment";
  export default {
    name: 'HandleEquipment',
    components: {
      Equipment
    }
  }
</script>