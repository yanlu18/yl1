
import "@/mock/MessageBoard.mock"

// 其他mock文件可以加在后面