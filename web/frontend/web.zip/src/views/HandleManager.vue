<template>
  <div id="handleManager">
    <Manager/>
  </div>
</template>

<script>
  import Manager from "@/components/Manager";
  export default {
    name: 'HandleManager',
    components: {
      Manager
    }
  }
</script>