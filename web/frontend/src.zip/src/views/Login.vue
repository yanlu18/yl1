<template>
  <div id="rigister">
    <LoginBoard/>
  </div>
</template>

<script>
  import LoginBoard from "@/components/LoginBoard";
  export default {
    name: 'Login',
    components: {
      LoginBoard
    }
  }
</script>